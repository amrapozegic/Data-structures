#include"RezultatIspita.hpp"

RezultatIspita::RezultatIspita(int index,int ocjena,std::string nazivPredmeta,Datum datum)
  :index_{index},ocjena_{ocjena},nazivPredmeta_{nazivPredmeta},datum_{datum}{}


