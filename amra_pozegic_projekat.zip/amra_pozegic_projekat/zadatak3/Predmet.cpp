#include"Predmet.hpp"

Predmet::Predmet(std::string nazivPredmeta)
:nazivPredmeta_{nazivPredmeta}
{}


