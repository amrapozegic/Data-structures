#include <iostream>


class Predmet{
  public:

    Predmet(std::string);

std::string getNazivPredmeta(){
return nazivPredmeta_;
}
  
private:
  std::string nazivPredmeta_;
  };

