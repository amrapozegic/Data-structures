#include"Datum.hpp"

void Datum::printDatum(){
std::cout << godina_<<"."<<mjesec_<<"."<<dan_;
}
