#include <list>
#include <vector>
#include <iterator>
#include<stdexcept>
#include <iostream>
#include <algorithm>

template <typename T,typename E>
  class UnorderedMap{
    using value_type=std::pair<T,E>;
    using bucket_type=std::list<value_type>;
  public:

class Iterator;

UnorderedMap();

void emplace(T kljuc,E vrijednost);
E& operator[](T kljuc);
const E& operator[](T kljuc) const;
bool erase(T kljuc);
Iterator find(T kljuc);

Iterator begin();

Iterator end();
  
private:
std::vector<bucket_type> collector_; 

size_t capacity_;
size_t size_;

  
long hashFunction(std::string kljuc,size_t D);
  
};

template<typename T,typename E>
UnorderedMap<T,E>::UnorderedMap()
:capacity_{107},size_{0}
{
collector_.resize(107);
}

template<typename T,typename E>
long UnorderedMap<T,E>::hashFunction(std::string k,size_t D){
    long h=0;
for (int i=0; i<k.length(); i++)
{
h = (h << 4) | ( h >> 28);
h += (long) k[i];
}
return h % D;
}

template<typename T,typename E>
void UnorderedMap<T,E>::emplace(T kljuc,E vrijednost){
long index=hashFunction(kljuc,capacity_);
bucket_type& bucket=collector_[index];
auto it=std::find_if(bucket.begin(),bucket.end(),[&kljuc](value_type& b ){
    return b.first==kljuc;
    });
if(it!=bucket.end())
  throw std::invalid_argument("Ova vrijednost se već nalazi u mapi ");
  else{
bucket.push_back(value_type{kljuc,vrijednost});
++size_;}
}



template<typename T,typename E>
E& UnorderedMap<T,E>::operator[](T kljuc){
long index=hashFunction(kljuc,capacity_);
bucket_type& bucket=collector_[index];

auto it=std::find_if(bucket.begin(),bucket.end(),[&kljuc](value_type& b ){
    return b.first==kljuc;
    });
if(it!=bucket.end())
return it->second;  
else{
bucket.push_back(value_type{kljuc,E()});
++size_;
return bucket.back().second;
  }
}


template<typename T,typename E>
bool UnorderedMap<T,E>::erase(T kljuc){
long index=hashFunction(kljuc,capacity_);
bucket_type& bucket=collector_[index];

auto it=std::find_if(bucket.begin(),bucket.end(),[&kljuc](value_type& b ){
    return b.first==kljuc;
    });
if(it!=bucket.end()){
bucket.erase(it);
--size_;
return true;
}else{
return false;}
}


template<typename T,typename E>
typename UnorderedMap<T,E>::Iterator UnorderedMap<T,E>::find(T kljuc ){
long index=hashFunction(kljuc,capacity_);
bucket_type& bucket=collector_[index];//nademo baket
int i=0;
for (auto it=bucket.begin();it!=bucket.end();it++){
if(it->first==kljuc)
return Iterator(collector_,index,i);
}
  return end();
 }


template<typename T,typename E>
class UnorderedMap<T,E>::Iterator : public std::iterator<std::bidirectional_iterator_tag,std::pair<T,E>>{

public:
Iterator(std::vector<bucket_type>,int,int);

Iterator& operator++();
Iterator operator++(int index);
Iterator& operator--();
Iterator operator--(int index);

bool operator==(const Iterator& other){
return bucketNumber_==other.bucketNumber_ && position_==other.position_;
}

bool operator!=(const Iterator& other){
return bucketNumber_!=other.bucketNumber_ || position_!=other.position_;
}



std::pair<T,E>* operator->();

  private:
  std::vector<bucket_type> ptr_;
  int bucketNumber_;
  int position_;
};


template<typename T,typename E>
UnorderedMap<T,E>::Iterator::Iterator(std::vector<bucket_type> ptr,int bucketNumber,int position)
:bucketNumber_{bucketNumber},position_{position},ptr_{ptr}
{
  while(ptr_[bucketNumber_].size()==0 && bucketNumber_<106)
  ++bucketNumber_;

  }

template<typename T,typename E>
typename UnorderedMap<T,E>::Iterator UnorderedMap<T,E>::begin(){
return Iterator(collector_,1,0);
}


template<typename T,typename E>
typename UnorderedMap<T,E>::Iterator UnorderedMap<T,E>::end(){
return Iterator(collector_,106,5);
}


template<typename T,typename E>
std::pair<T,E>* UnorderedMap<T,E>::Iterator::operator->(){
bucket_type& bucket=ptr_[bucketNumber_];
auto it=bucket.begin();
int i=0;
while(i<position_){
++i;
++it;}
return &(*it);
}


template<typename T,typename E>
typename UnorderedMap<T,E>::Iterator& UnorderedMap<T,E>::Iterator::operator++(){
position_++;
if(position_>=ptr_[bucketNumber_].size()){
if(bucketNumber_<106){
++bucketNumber_;
position_=0;
}
while(ptr_[bucketNumber_].size()==0&&bucketNumber_<106)
  ++bucketNumber_;
if(position_>=ptr_[bucketNumber_].size() && bucketNumber_==106)
  position_=5;
}

return *this;
}


template<typename T,typename E>
typename UnorderedMap<T,E>::Iterator UnorderedMap<T,E>::Iterator::operator++(int index){
auto temp=*this;
position_++;
if(position_>=ptr_[bucketNumber_].size()){
if(bucketNumber_<106){
++bucketNumber_;
position_=0;
}
while(ptr_[bucketNumber_].size()==0&&bucketNumber_<106)
  ++bucketNumber_;
if(position_>=ptr_[bucketNumber_].size() && bucketNumber_==106)
  position_=5;
}
return temp;
}

template<typename T,typename E>
typename UnorderedMap<T,E>::Iterator& UnorderedMap<T,E>::Iterator::operator--(){
if(position_>ptr_[bucketNumber_].size())
position_=ptr_[bucketNumber_].size();
--position_;
if(position_<0){
  --bucketNumber_;
while(ptr_[bucketNumber_].size()==0&&bucketNumber_>0)
  --bucketNumber_;
position_=ptr_[bucketNumber_].size()-1;}


return *this;
}

template<typename T,typename E>
typename UnorderedMap<T,E>::Iterator UnorderedMap<T,E>::Iterator::operator--(int index){
auto temp=*this;
if(position_>ptr_[bucketNumber_].size())
position_=ptr_[bucketNumber_].size();
--position_;
if(position_<0){
  --bucketNumber_;
while(ptr_[bucketNumber_].size()==0&&bucketNumber_>0)
  --bucketNumber_;
position_=ptr_[bucketNumber_].size()-1;}


return temp;
}
